"""Course recommendation starter application."""
